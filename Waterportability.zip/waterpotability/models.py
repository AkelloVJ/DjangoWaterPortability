from django.db import models

class WaterQuality(models.Model):
    ph = models.FloatField()
    hardness = models.FloatField()
    solids = models.FloatField()
    chloramines = models.FloatField()
    sulfate = models.FloatField()
    conductivity = models.FloatField()
    organic_carbon = models.FloatField()
    trihalomethanes = models.FloatField()
    turbidity = models.FloatField()
    potability = models.IntegerField()
