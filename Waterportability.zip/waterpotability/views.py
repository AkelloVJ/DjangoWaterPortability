from django.shortcuts import render
from .forms import WaterQualityForm
import pickle
import numpy as np

# Load the trained model
def load_model():
    with open('watermodel.sav', 'rb') as model_file:
        model = pickle.load(model_file)
    return model

# Function to predict water potability
def predict_potability(request):
    if request.method == 'POST':
        form = WaterQualityForm(request.POST)
        if form.is_valid():
            model = load_model()
            new_data = form.cleaned_data
            data_list = [new_data['ph'], new_data['hardness'], new_data['solids'], new_data['chloramines'], new_data['sulfate'],
                         new_data['conductivity'], new_data['organic_carbon'], new_data['trihalomethanes'], new_data['turbidity']]
            prediction = model.predict([data_list])[0]
            result = "Safe" if prediction == 1 else "Unsafe"
            return render(request, 'water_quality/prediction_result.html', {'result': result})
    else:
        form = WaterQualityForm()
    return render(request, 'water_quality/input_form.html', {'form': form})
