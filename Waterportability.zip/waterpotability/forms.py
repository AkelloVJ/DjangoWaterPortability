from django import forms
from .models import WaterQuality

class WaterQualityForm(forms.ModelForm):
    class Meta:
        model = WaterQuality
        fields = '__all__'
